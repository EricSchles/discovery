#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
test_pyfpds
----------------------------------

Tests for `pyfpds` module.
"""

import unittest

from pyfpds import pyfpds


class TestPyfpds(unittest.TestCase):

    def setUp(self):
        pass

    def test_something(self):
        pass

    def tearDown(self):
        pass

if __name__ == '__main__':
    unittest.main()